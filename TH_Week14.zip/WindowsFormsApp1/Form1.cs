﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlconnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string sqlquery;
        DataTable dtteamaway = new DataTable();
        DataTable dtteamhome = new DataTable();
        DataTable dtlastmatchdate = new DataTable();
        DataTable dtcount = new DataTable();
        DataTable dt = new DataTable(); 
        DataTable player = new DataTable();
        DataTable dtminute = new DataTable();
        
      



        private void Form1_Load(object sender, EventArgs e)
        {
            sqlconnect = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            sqlconnect.Open();
            sqlquery = "SELECT team_id, team_name from team;";
            sqlCommand = new MySqlCommand(sqlquery,sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteamaway);
            if (dtteamaway.Rows.Count > 0)
            {
                cb_teamaway.DataSource = dtteamaway;
                cb_teamaway.DisplayMember = "team_name";
                cb_teamaway.ValueMember = "team_id";
                cb_teamaway.SelectedIndex = -1;
            }
            sqlquery = "SELECT team_name, team_id from team;";
            sqlCommand = new MySqlCommand(sqlquery, sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteamhome);
            if(dtteamhome.Rows.Count > 0)
            {
                cb_teamhome.DataSource = dtteamhome;
                cb_teamhome.DisplayMember = "team_name";
                cb_teamhome.ValueMember = "team_id";
                cb_teamhome.SelectedIndex = -1;
            }
            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");
            dtminute.Columns.Add("Minute");

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                sqlquery = "SELECT match_date FROM `match` ORDER BY match_date DESC LIMIT 1";
                sqlCommand = new MySqlCommand(sqlquery, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtlastmatchdate = new DataTable();
                sqlDataAdapter.Fill(dtlastmatchdate);

                if (dtlastmatchdate.Rows.Count > 0)
                {
                    DateTime lastmatchdate = Convert.ToDateTime(dtlastmatchdate.Rows[0]["match_date"]);
                    DateTime tanggaldipilih = dtp_match.Value;
                    if (tanggaldipilih < lastmatchdate)
                    {
                        MessageBox.Show("Selected date is earlier than the last match date");
                    }
                    else
                    {
                        
                        string year = tanggaldipilih.Year.ToString();
                        try
                        {
                            
                            sqlquery = $"SELECT IFNULL(COUNT(*), 0) AS match_count FROM `match` WHERE YEAR(match_date) = '{tanggaldipilih.Year}'";
                            sqlCommand = new MySqlCommand(sqlquery, sqlconnect);
                            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                            dtcount = new DataTable();
                            sqlDataAdapter.Fill(dtcount);
                            int matchcount = Convert.ToInt32(dtcount.Rows[0]["match_count"]) + 1;
                            string matchNumber = matchcount.ToString("000");
                            txtbox_matchid.Text = $"{year}{matchNumber}";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }

                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
    }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {

            

        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {

            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if(txtbox_minute.Text != null)
            dt.Rows.Add(cb_team.Text,cb_player.Text, cb_type.SelectedItem.ToString());
            dataGridView1.DataSource = dt;
            dtminute.Rows.Add(txtbox_minute.Text);
            
        }

        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if(dt.Rows.Count > 0 & dtminute.Rows.Count > 0)
            {
                if (dt.Rows.Count > 0 && dtminute.Rows.Count > 0)
                {
                    string matchid = txtbox_matchid.Text;
                    string matchdate = dtp_match.Value.ToString("yyyy-MM-dd");
                    string teamHomeId = cb_teamhome.SelectedValue.ToString();
                    string teamAwayId = cb_teamaway.SelectedValue.ToString();
                    string refereeId = "M002"; 
                    int goalHome = 0;
                    int goalAway = 0;

                    foreach (DataRow row in dt.Rows)
                    {
                        if (row["Team"].ToString() == cb_teamhome.Text && (row["Type"].ToString() == "GO" || row["Type"].ToString() == "GP" || row["Type"].ToString() == "GW"))
                        {
                            goalHome++;
                        }
                    }
                    foreach (DataRow row in dt.Rows)
                    {
                        if (row["Team"].ToString() == cb_teamaway.Text && (row["Type"].ToString() == "GO" || row["Type"].ToString() == "GP" || row["Type"].ToString() == "GW"))
                        {
                            goalAway++;
                        }
                    }

                    try
                    {
                        sqlquery = $"INSERT INTO `match` (match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, `delete`) VALUES (@match_id, @match_date, @team_home, @team_away, @goal_home, @goal_away, @referee_id, 0)";
                        sqlCommand = new MySqlCommand(sqlquery, sqlconnect);
                        sqlCommand.Parameters.AddWithValue("@match_id", matchid);
                        sqlCommand.Parameters.AddWithValue("@match_date", matchdate);
                        sqlCommand.Parameters.AddWithValue("@team_home", teamHomeId);
                        sqlCommand.Parameters.AddWithValue("@team_away", teamAwayId);
                        sqlCommand.Parameters.AddWithValue("@goal_home", goalHome);
                        sqlCommand.Parameters.AddWithValue("@goal_away", goalAway);
                        sqlCommand.Parameters.AddWithValue("@referee_id", refereeId);
                        sqlCommand.ExecuteNonQuery();

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            DataRow row = dt.Rows[i];
                            DataRow minuteRow = dtminute.Rows[i]; 
                            string teamId = GetTeamIdByName(row["Team"].ToString());
                            string playerId = GetPlayerIdByName(row["Player"].ToString());
                            sqlquery = "INSERT INTO dmatch (match_id, minute, team_id, player_id, type, `delete`) VALUES (@match_id, @minute, @team_id, @player_id, @type, 0)";
                            sqlCommand = new MySqlCommand(sqlquery, sqlconnect);
                            sqlCommand.Parameters.AddWithValue("@match_id", matchid);
                            sqlCommand.Parameters.AddWithValue("@minute", minuteRow["minute"]);
                            sqlCommand.Parameters.AddWithValue("@team_id", teamId);
                            sqlCommand.Parameters.AddWithValue("@player_id",playerId);
                            sqlCommand.Parameters.AddWithValue("@type", row["Type"]);
                            sqlCommand.ExecuteNonQuery();
                        }

                        MessageBox.Show("Data inserted successfully.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        sqlconnect.Close();
                    }
                }
                else
                {
                    MessageBox.Show("No data to insert.");
                }
                
            }
            
            

        }
        private string GetPlayerIdByName(string playerName)
        {
                foreach (DataRow row in player.Rows)
                {
                    if (row["player_name"].ToString() == playerName)
                    {
                        return row["player_id"].ToString();
                    }
                }
                return null;
        }
        private string GetTeamIdByName(string teamName)
        {
            foreach (DataRow row in dtteamhome.Rows)
            {
                if (row["team_name"].ToString() == teamName)
                {
                    return row["team_id"].ToString();
                }
            }
            return null; 
        }
        private void cb_teamhome_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cb_teamaway.SelectedItem != null & cb_teamhome.SelectedItem != null)
            {
                if (cb_teamhome.SelectedValue.ToString() == cb_teamaway.SelectedValue.ToString())
                {
                    MessageBox.Show("nda boleh sama");
                }
                else
                {
                    cb_team.Items.Clear();
                    DataTable selectedTeams = new DataTable();
                    selectedTeams.Columns.Add("team_name");
                    selectedTeams.Columns.Add("team_id");

                    DataRow homeTeamRow = selectedTeams.NewRow();
                    homeTeamRow["team_name"] = cb_teamhome.Text;
                    homeTeamRow["team_id"] = cb_teamhome.SelectedValue.ToString();
                    selectedTeams.Rows.Add(homeTeamRow);

                    cb_team.DataSource = selectedTeams;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.SelectedIndex = -1;
                }

            }

        }

        private void cb_teamaway_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cb_teamaway.SelectedItem != null & cb_teamhome.SelectedItem != null)
            {
                if (cb_teamaway.SelectedValue.ToString() == cb_teamhome.SelectedValue.ToString())
                {
                    MessageBox.Show("nda boleh sama");
                }
                else
                {
                    cb_team.Items.Clear();
                    DataTable selectedTeams = new DataTable();
                    selectedTeams.Columns.Add("team_name");
                    selectedTeams.Columns.Add("team_id");

                    DataRow homeTeamRow = selectedTeams.NewRow();
                    homeTeamRow["team_name"] = cb_teamhome.Text;
                    homeTeamRow["team_id"] = cb_teamhome.SelectedValue.ToString();
                    selectedTeams.Rows.Add(homeTeamRow);

                    DataRow awayTeamRow = selectedTeams.NewRow();
                    awayTeamRow["team_name"] = cb_teamaway.Text;
                    awayTeamRow["team_id"] = cb_teamaway.SelectedValue.ToString();
                    selectedTeams.Rows.Add(awayTeamRow);

                    cb_team.DataSource = selectedTeams;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.SelectedIndex = -1;
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int rowIndex = dataGridView1.CurrentRow.Index;
                if (rowIndex >= 0 && rowIndex < dt.Rows.Count)
                {
                    dt.Rows.RemoveAt(rowIndex);
                }
            }
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }

        private void cb_team_SelectionChangeCommitted(object sender, EventArgs e)
        {

        }

        private void cb_team_SelectedValueChanged(object sender, EventArgs e)
        {
            sqlquery = $"SELECT player_name, player_id FROM player WHERE team_id = '{cb_team.SelectedValue}'";
            sqlCommand = new MySqlCommand(sqlquery, sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            player = new DataTable();
            sqlDataAdapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
            dataGridView2.DataSource = player;
            
            

        }
    }
}
